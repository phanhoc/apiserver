package crypto

import (
	"fmt"
)

type AccountInfo struct {
	AccountNumber uint32
	PublicKey     []byte
	PrivateKey    []byte
}


// Dump displays the AccountInfo to standard output with newlines
func (a *AccountInfo) Dump() {
	fmt.Println("AccountNumber:", a.AccountNumber)
	fmt.Printf("PublicKey: %s\n", a.PublicKey)
	fmt.Printf("PrivateKey: %s\n", a.PrivateKey)
}