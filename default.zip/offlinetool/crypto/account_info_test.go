package crypto

import (
	"path/filepath"
	"log"
)

func ExampleAccountInfo() {

	acct := AccountInfo{}
	acct.AccountNumber = 100
	acct.PublicKey = []byte("xpub6D4BDPcP2GT577Vvch3R8wDkScZWzQzMMUm3PWbmWvVJrZwQY4VUNgqFJPMM3No2dFDFGTsxxpG5uJh7n7epu4trkrX7x7DogT5Uv6fcLW5")
	acct.PrivateKey = []byte("xprv9z4pot5VBttmtdRTWfWQmoH1taj2axGVzFqSb8C9xaxKymcFzXBDptWmT7FwuEzG3ryjH4ktypQSAewRiNMjANTtpgP4mLTj34bhnZX7UiM")

	filename := filepath.Join("./", "keystore.json")

	// Write to file
	err := NewEncrypter(filename, nil).WriteEncryptedFile(acct)
	if err != nil {
		log.Fatal(err)
	}

	// Ok, now reading encrypted file
	var a AccountInfo
	err = NewEncrypter(filename, nil).ReadEncrytedFile(&a)
	if err != nil {
		log.Fatal(err)
	}
	a.Dump()

	// Output:
	// AccountNumber: 100
	// PublicKey: xpub6D4BDPcP2GT577Vvch3R8wDkScZWzQzMMUm3PWbmWvVJrZwQY4VUNgqFJPMM3No2dFDFGTsxxpG5uJh7n7epu4trkrX7x7DogT5Uv6fcLW5
	// PrivateKey: xprv9z4pot5VBttmtdRTWfWQmoH1taj2axGVzFqSb8C9xaxKymcFzXBDptWmT7FwuEzG3ryjH4ktypQSAewRiNMjANTtpgP4mLTj34bhnZX7UiM
}
