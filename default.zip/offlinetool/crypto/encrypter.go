package crypto

import (
	"encoding/json"
	"github.com/btcsuite/btcwallet/snacl"
	"encoding/hex"
	"io/ioutil"
	"strings"
)

const defaultPassphrase = "123@123q"

type cipherOptions struct {
	N, R, P int
}

var defaultCipherOptions = cipherOptions{
	N: 262144, // 2^18
	R: 8,
	P: 1,
}

type encryptedJSON struct {
	Data   string `json:"data"`
	Params string `json:"cipherparams"`
}

type Encrypter struct {
	filePath   string
	passPhrase *string
	option     *cipherOptions
}

// NewEncrypter creates new encryter and returns its. If the
// passPhrase is nil, encrypter will use default passphrase of system
func NewEncrypter(filePath string, passPhrase *string) (*Encrypter) {
	return &Encrypter{filePath: filePath, passPhrase: passPhrase, option: &defaultCipherOptions}
}

// WriteEncryptedFile writes a struct to encrypted file.
func (e *Encrypter) WriteEncryptedFile(v interface{}) error {
	data, err := json.Marshal(v)
	if err != nil {
		return err
	}

	err = e.writeEncryptedToFile(data)
	if err != nil {
		return err
	}
	return nil
}

//ReadEncrytedFile reads struct from encrypted file.
func (e *Encrypter) ReadEncrytedFile(v interface{}) error {
	raw, err := e.getRawDataFromEncryptedFile()
	if err != nil {
		return err
	}
	return e.newInfoFromJSON(raw, v)
}

// writeEncryptedToFile is helper to encrypt data and write to file keystore
func (e *Encrypter) writeEncryptedToFile(data []byte) error {
	pass := e.getPassPhrase(e.passPhrase)
	secretKey, err := snacl.NewSecretKey(
		&pass,
		e.option.N,
		e.option.R,
		e.option.P)
	if err != nil {
		return err
	}

	encryptedData, err := secretKey.Encrypt(data)
	if err != nil {
		return err
	}

	cipherParams := secretKey.Marshal()
	encrypted, err := json.Marshal(&encryptedJSON{
		Data:   hex.EncodeToString(encryptedData),
		Params: hex.EncodeToString(cipherParams),
	})

	if err := ioutil.WriteFile(e.filePath, encrypted, 0600); err != nil {
		return err
	}
	return nil
}

// getRawDataFromEncryptedFile is helper to decrypted keystore file  and return raw data
func (e *Encrypter) getRawDataFromEncryptedFile() ([]byte, error) {
	e.filePath = strings.Trim(e.filePath, " ")
	data, err := ioutil.ReadFile(e.filePath)
	if err != nil {
		return nil, err
	}

	var encrypted encryptedJSON
	if err := json.Unmarshal([]byte(data), &encrypted); err != nil {
		return nil, err
	}

	var secretKey snacl.SecretKey
	cipherParams, err := hex.DecodeString(encrypted.Params)
	if err != nil {
		return nil, err
	}

	secretKey.Unmarshal(cipherParams)
	pass := e.getPassPhrase(e.passPhrase)
	secretKey.DeriveKey(&pass)
	if err != nil {
		return nil, err
	}

	encryptedData, err := hex.DecodeString(encrypted.Data)
	if err != nil {
		return nil, err
	}

	var raw []byte
	raw, err = secretKey.Decrypt(encryptedData)
	if err != nil {
		return nil, err
	}
	return raw, err
}

// getPassPhrase return default passphrase if passphrase input is nil, otherwise return passphrase input
func (e *Encrypter) getPassPhrase(passPhrase *string) ([]byte) {
	pass := ""
	if passPhrase != nil {
		pass = *passPhrase
	} else {
		pass = defaultPassphrase
	}
	return []byte(pass)
}

// newInfoFromJSON return struct from raw data
func (e *Encrypter) newInfoFromJSON(data []byte, v interface{}) error {
	if err := json.Unmarshal(data, &v); err != nil {
		return err
	}
	return nil
}
