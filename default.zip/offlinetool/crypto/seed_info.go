package crypto

import (
	"fmt"
	"encoding/hex"
)

type SeedInfo struct {
	Seed []byte
}

// Dump displays the SeedInfo to standard output with newlines
func (s *SeedInfo) Dump() {
	fmt.Println("Seed:", hex.EncodeToString(s.Seed))
}