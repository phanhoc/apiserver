package crypto

import (
	"path/filepath"
	"log"
	"testing"
	"encoding/hex"
)

func TestWriteSeedEncryptedInfo(t *testing.T) {
	seed := SeedInfo{}
	s, _ := hex.DecodeString("4ac674fe781e53daa6325db2e7bb63393e82e8ed56eee488c6f3a391a2a1fb50bb775498c671f6b18ef9c1848873e86ce82d4fb8ac444113bce8600fc5a98467")
	seed.Seed = s

	filename := filepath.Join("./", "keystoreSeed.json")
	passPhrase := "qwertyu@123"
	// Write to file
	err := NewEncrypter(filename, &passPhrase).WriteEncryptedFile(seed)
	if err != nil {
		log.Fatal(err)
	}

	// reading encrypted file
	var si SeedInfo
	err = NewEncrypter(filename, &passPhrase).ReadEncrytedFile(&si)
	if err != nil {
		log.Fatal(err)
	}
	si.Dump()

	// Write file again
	err = NewEncrypter(filename, &passPhrase).WriteEncryptedFile(seed)
	if err != nil {
		log.Fatal(err)
	}

	// reading encrypted file
	var se SeedInfo
	err = NewEncrypter(filename, nil).ReadEncrytedFile(&se)
	if err == nil {
		log.Fatal(err)
	}

	se.Dump()

}
