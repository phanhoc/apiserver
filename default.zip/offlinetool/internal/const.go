package internal

const (
	// Default entropy size for mnemonic
	DefaultEntropySize = 256
	// Default seed pass. it used to generate seed from mnemonic( BIP39 ). Don't change if determined
	DefaultSeedPass = ""
	// Api port
	OfflineToolPort = ":50052"
	// Wallet seed size
	WalletSeedSize = 64
)
