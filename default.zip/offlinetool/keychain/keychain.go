package keychain

import (
	"github.com/btcsuite/btcutil/hdkeychain"
	"strconv"
	"fmt"
	"errors"
	"github.com/btcsuite/btcd/btcec"
	"github.com/btcsuite/btcutil"
	"github.com/btcsuite/btcutil/base58"
	"golang.org/x/crypto/ripemd160"
	gethCrypto "github.com/ethereum/go-ethereum/crypto"
)
var(
	// Hardened symbol
	hardenedSymbol = "'"
	// Slash symbol
	slashSymbol = "/"
	// purposePath is the hierarchical deterministic extended key of purpose path of BIP0044
	purposePath = "m/44'/"
)
const (
	// MaxAccountNum is the maximum allowed account number.  This value was
	// chosen because accounts are hardened children and therefore must
	// not exceed the hardened child range of extended keys and it provides
	// a reserved account at the top of the range for supporting imported
	// addresses.
	maxAccountNum = hdkeychain.HardenedKeyStart - 2 // 2^31 - 2
	// maxCoinType is the maximum allowed coin type used when structuring
	// the BIP0044 multi-account hierarchy.  This value is based on the
	// limitation of the underlying hierarchical deterministic key
	// derivation.
	maxCoinType = hdkeychain.HardenedKeyStart - 1
	// externalBranch is the child number to use when performing BIP0044
	// style hierarchical deterministic key derivation for the external
	// branch.
	externalBranch uint32 = 0
	// MaxAddressesPerAccount is the maximum allowed number of addresses
	// per account number.  This value is based on the limitation of
	// the underlying hierarchical deterministic key derivation.
	MaxAddressesPerAccount = hdkeychain.HardenedKeyStart - 1
	// btcCoinType is coin type of Bitcoin
	btcCoinType = 0
	// ethCoinType is coin type of Ether
	ethCoinType = 60
)

type KeyChain struct {
	master   *hdkeychain.ExtendedKey
	coinType uint32
}

type AddressInfo struct {
	AddressIndex uint32
	AddressPath  string
	Address      string
}
// NewKeyChain creates new instance of KeyChain struct with master key and coinType
func NewKeyChain(masterKey *hdkeychain.ExtendedKey, coinType uint32) (*KeyChain) {
	return &KeyChain{master: masterKey, coinType: coinType}
}
// NextAccount returns the specified number of next chained account from the master
func NextAccount(master *hdkeychain.ExtendedKey, coinType uint32, numAcct uint32, index uint32) ([]string, error) {
	// Derive the cointype key according to BIP0044.
	coinTypeKeyPriv, err := deriveCoinTypeKey(master, coinType)
	if err != nil {
		err := errors.New("failed to derive coinType extended key")
		return nil, err
	}
	defer  coinTypeKeyPriv.Zero()

	coinTypePath := purposePath + strconv.FormatUint(uint64(coinType), 10) + hardenedSymbol
	acctPath := make([]string, 0, numAcct)

	for i := index; i < (index + numAcct); i++ {
		// Derive the account key for the first account according to BIP0044.
		_, err := deriveAccountKey(coinTypeKeyPriv, i)
		if err != nil {
			// The seed is unusable if the any of the children in the
			// required hierarchy can't be derived due to invalid child.
			if err == hdkeychain.ErrInvalidChild {
				str := "the provided seed is unusable"
				return nil, errors.New(str)
			}
			return nil, err
		}
		//TODO: save account info into cache

		var path = coinTypePath + slashSymbol + strconv.FormatUint(uint64(i),10) + hardenedSymbol
		acctPath = append(acctPath, path)
	}

	return acctPath, nil
}

// ExportAccount returns the account extended key as a human-readable base58-encoded string
func ExportAccount(master *hdkeychain.ExtendedKey, coinType uint32, acct uint32, watch_only bool) (string, error)  {
	// Derive the cointype key according to BIP0044.
	coinTypeKeyPriv, err := deriveCoinTypeKey(master, coinType)
	if err != nil {
		err := errors.New("failed to derive coinType extended key")
		return "", err
	}
	defer  coinTypeKeyPriv.Zero()

	// Derive the account key for the account number according to BIP0044.
	acctKeyPriv, err := deriveAccountKey(coinTypeKeyPriv, acct)
	if err != nil {
		// The seed is unusable if the any of the children in the
		// required hierarchy can't be derived due to invalid child.
		if err == hdkeychain.ErrInvalidChild {
			str := "the provided seed is unusable"
			return "", errors.New(str)
		}
		return "", err
	}

	if !watch_only {
		return acctKeyPriv.String(), nil
	}

	// Get the public extended key for the account.
	acctKeyPub, err := acctKeyPriv.Neuter()
	if err != nil {
		str := "failed to convert private key for account 0"
		return "", errors.New(str)
	}

	return acctKeyPub.String(), nil
}

// NextAddress gets next address of account from index. If index is nill, NextAddress will return
// continues number address with start index is 0 by default
func (k *KeyChain) NextAddress(acct uint32, numAddresses uint32, index *uint32) ([]AddressInfo, error) {
	if numAddresses <= 0{
		return nil, errors.New("Input number address invalid")
	}
	addressesInfo := make([]AddressInfo, 0, numAddresses)

	acctKeyPriv, accountPath, err := k.deriveOneAccountKey(acct)
	if err != nil {
		// The seed is unusable if the any of the children in the
		// required hierarchy can't be derived due to invalid child.
		if err == hdkeychain.ErrInvalidChild {
			str := "the provided seed is unusable"
			return nil, errors.New(str)
		}
		return nil, err
	}
	// Get the public extended key for the account.
	acctKeyPub, err := acctKeyPriv.Neuter()
	if err != nil {
		str := "failed to convert private key for account 0"
		return nil, errors.New(str)
	}
	branchNum, startIndex := externalBranch, uint32(0)

	if index != nil {
		startIndex = *index
	}

	if numAddresses > MaxAddressesPerAccount || startIndex+numAddresses >
		MaxAddressesPerAccount {
		str := fmt.Sprintf("%d new addresses would exceed the maximum "+
			"allowed number of addresses per account of %d",
			numAddresses, MaxAddressesPerAccount)
		return nil, errors.New(str)
	}

	// Derive the appropriate branch key and ensure it is zeroed when done.
	branchKey, err := acctKeyPub.Child(branchNum)
	if err != nil {
		str := fmt.Sprintf("failed to derive extended key branch %d",
			branchNum)
		return nil, errors.New(str)
	}
	defer branchKey.Zero() // Ensure branch key is zeroed when done.
	nextIndex := startIndex
	for i := uint32(0); i < numAddresses; i++ {
		key, err := branchKey.Child(nextIndex)
		if err != nil {
			// When this particular child is invalid, skip to the
			// next index.
			if err == hdkeychain.ErrInvalidChild {
				nextIndex++
				continue
			}

			str := fmt.Sprintf("failed to generate child %d",
				nextIndex)
			return nil, errors.New(str)
		}
		pubKey, err := key.ECPubKey()
		if err != nil {
			return nil, err
		}
		address, err := k.deriveAddress(pubKey)
		if err != nil {
			return nil, err
		}
		addressInfo := AddressInfo{
			AddressIndex: nextIndex,
			AddressPath:  accountPath + slashSymbol + strconv.FormatUint(uint64(branchNum), 10) + slashSymbol + strconv.FormatUint(uint64(i+startIndex), 10),
			Address:      address,
		}
		addressesInfo = append(addressesInfo, addressInfo)
		nextIndex++
		key.Zero()
	}
	return addressesInfo, nil
}

// deriveCoinTypeKey derives the cointype key which can be used to derive the
// extended key for an account according to the hierarchy described by BIP0044
// given the coin type key.
//
// In particular this is the hierarchical deterministic extended key path:
// m/44'/<coin type>'
func deriveCoinTypeKey(masterNode *hdkeychain.ExtendedKey,
	coinType uint32) (*hdkeychain.ExtendedKey, error) {
	// Enforce maximum coin type
	if coinType > maxCoinType {
		err := fmt.Errorf("coin type may not exceed %d", strconv.FormatUint(hdkeychain.HardenedKeyStart-1, 10))
		return nil, err
	}

	// BIP0044 format:
	//  m/44'/<coin type>'/<account>'/<branch>/<address index>
	//
	// The branch is 0 for external addresses and 1 for internal addresses.

	// Derive the purpose key as a child of the master node.
	purpose, err := masterNode.Child( 44 + hdkeychain.HardenedKeyStart)
	if err != nil {
		return nil, err
	}

	// Derive the coin type key as a child of the purpose key.
	coinTypeKey, err := purpose.Child(coinType + hdkeychain.HardenedKeyStart)
	if err != nil {
		return nil, err
	}
	return coinTypeKey, nil
}

// deriveAccountKey derives the extended key for an account according to the
// hierarchy described by BIP0044 given the master node.
//
// In particular this is the hierarchical deterministic extended key path:
//   m/44'/<coin type>'/<account>'
func deriveAccountKey(coinTypeKey *hdkeychain.ExtendedKey,
	account uint32) (*hdkeychain.ExtendedKey, error) {
	// Enforce maximum account number.
	if account > maxAccountNum {
		err := fmt.Errorf("account number may not exceed " +
			strconv.FormatUint(hdkeychain.HardenedKeyStart-1, 10))
		return nil, err
	}

	// Derive the account key as a child of the coin type key.
	return coinTypeKey.Child(account + hdkeychain.HardenedKeyStart)
}

//deriveOneAccountKey derives one the extended key for an account according to the
// hierarchy described by BIP0044 given the master node.
func (k *KeyChain) deriveOneAccountKey(acct uint32) (*hdkeychain.ExtendedKey, string, error) {
	// Derive the cointype key according to BIP0044.
	coinTypeKeyPriv, err := deriveCoinTypeKey(k.master, k.coinType)
	if err != nil {
		err := errors.New("failed to derive coinType extended key")
		return nil, "", err
	}
	defer coinTypeKeyPriv.Zero()

	// Derive the account key for the account number according to BIP0044.
	acctKeyPriv, err := deriveAccountKey(coinTypeKeyPriv, acct)
	if err != nil {
		// The seed is unusable if the any of the children in the
		// required hierarchy can't be derived due to invalid child.
		if err == hdkeychain.ErrInvalidChild {
			str := "the provided seed is unusable"
			return nil, "", errors.New(str)
		}
		return nil, "", err
	}
	accountPath := purposePath + strconv.FormatUint(uint64(k.coinType), 10) + hardenedSymbol + slashSymbol + strconv.FormatUint(uint64(acct), 10) + hardenedSymbol
	return acctKeyPriv, accountPath, err
}

// deriveAddress return address as string foreach coinType base on public key
func (k *KeyChain) deriveAddress(pubKey *btcec.PublicKey) (string, error) {
	switch k.coinType {
	case btcCoinType:
		pubKeyHash := btcutil.Hash160(pubKey.SerializeCompressed())
		if len(pubKeyHash) != ripemd160.Size {
			return "", errors.New("pubKeyHash must be 20 bytes")
		}
		return base58.CheckEncode(pubKeyHash, 0x00), nil
	case ethCoinType:
		address := gethCrypto.PubkeyToAddress(*pubKey.ToECDSA())
		return address.Hex(), nil
	}
	return "", nil
}