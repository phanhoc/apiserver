package keychain_test

import (
	"testing"
	"github.com/btcsuite/btcutil/hdkeychain"
	kc "nextop/c-horde/offlinetool/keychain"
	"strings"
	"reflect"
)

func TestKeyChain_NextAccount(t *testing.T) {
	// The private extended keys for test vectors in [BIP32].
	testVec1MasterPrivKey := "xprv9s21ZrQH143K3QTDL4LXw2F7HEK3wJUD2nW2nRk4stbPy6cq3jPPqjiChkVvvNKmPGJxWUtg6LnF5kejMRNNU3TGtRBeJgk33yuGBxrMPHi"
	//testVec2MasterPrivKey := "xprv9s21ZrQH143K31xYSDQpPDxsXRTUcvj2iNHm5NUtrGiGG5e2DtALGdso3pGz6ssrdK4PFmM8NSpSBHNqPqm55Qn3LqFtT2emdEXVYsCzC2U"
	tests := []struct {
		name     string
		master   string
		coinType uint32
		numAcct  uint32
		index    uint32
		wantPath []string
	}{
		// Test 1
		{
			name:     "Test case 1",
			master:   testVec1MasterPrivKey,
			coinType: 0,
			numAcct:  1,
			index:    0,
			wantPath: []string{"m/44'/0'/0'"},
		},
		{
			name:     "Test case 2",
			master:   testVec1MasterPrivKey,
			coinType: 0,
			numAcct:  1,
			index:    2,
			wantPath: []string{"m/44'/0'/2'"},
		},
		{
			name:     "Test case 3",
			master:   testVec1MasterPrivKey,
			coinType: 0,
			numAcct:  3,
			index:    0,
			wantPath: []string{"m/44'/0'/0'", "m/44'/0'/1'", "m/44'/0'/2'"},
		},
		{
			name:     "Test case 4",
			master:   testVec1MasterPrivKey,
			coinType: 0,
			numAcct:  3,
			index:    1,
			wantPath: []string{"m/44'/0'/1'", "m/44'/0'/2'", "m/44'/0'/3'"},
		},
		{
			name:     "Test case 5",
			master:   testVec1MasterPrivKey,
			coinType: 1,
			numAcct:  1,
			index:    0,
			wantPath: []string{"m/44'/1'/0'"},
		},
		{
			name:     "Test case 6",
			master:   testVec1MasterPrivKey,
			coinType: 1,
			numAcct:  1,
			index:    2,
			wantPath: []string{"m/44'/1'/2'"},
		},
		{
			name:     "Test case 7",
			master:   testVec1MasterPrivKey,
			coinType: 1,
			numAcct:  3,
			index:    0,
			wantPath: []string{"m/44'/1'/0'", "m/44'/1'/1'", "m/44'/1'/2'"},
		},
		{
			name:     "Test case 8",
			master:   testVec1MasterPrivKey,
			coinType: 1,
			numAcct:  3,
			index:    1,
			wantPath: []string{"m/44'/1'/1'", "m/44'/1'/2'", "m/44'/1'/3'"},
		},
		{
			name:     "Test case 9",
			master:   testVec1MasterPrivKey,
			coinType: 60,
			numAcct:  1,
			index:    0,
			wantPath: []string{"m/44'/60'/0'"},
		},
		{
			name:     "Test case 10",
			master:   testVec1MasterPrivKey,
			coinType: 60,
			numAcct:  1,
			index:    2,
			wantPath: []string{"m/44'/60'/2'"},
		},
		{
			name:     "Test case 11",
			master:   testVec1MasterPrivKey,
			coinType: 60,
			numAcct:  3,
			index:    0,
			wantPath: []string{"m/44'/60'/0'", "m/44'/60'/1'", "m/44'/60'/2'"},
		},
		{
			name:     "Test case 12",
			master:   testVec1MasterPrivKey,
			coinType: 60,
			numAcct:  3,
			index:    1,
			wantPath: []string{"m/44'/60'/1'", "m/44'/60'/2'", "m/44'/60'/3'"},
		},
	}
tests:
	for i, test := range tests {
		extKey, err := hdkeychain.NewKeyFromString(test.master)
		if err != nil {
			t.Errorf("NewKeyFromString #%d (%s): unexpected error "+
				"creating extended key: %v", i, test.name, err)
			continue
		}
		paths, err := kc.NextAccount(extKey, test.coinType, test.numAcct, test.index)
		if err != nil {
			t.Errorf("NextAccount #%d (%s): unexpected error getting next account: %v", i, test.name, err)
			continue
		}

		if len(paths) != len(test.wantPath) {
			t.Errorf("Path #%d (%s): don't enough the number of account -- got: %d, want: %d", i, test.name,
				len(paths), len(test.wantPath))
			continue
		}

		for j, path := range paths {
			if strings.Compare(path, test.wantPath[j]) != 0 {
				t.Errorf("Path #%d (%s): mismatched the value [%d] -- got: %s, want: %s", i, test.name,
					j, path, test.wantPath[j])
				continue tests
			}
		}
	}
}
func TestKeyChain_ExportAccount(t *testing.T) {
	// The private extended keys for test vectors in [BIP32].
	testVec1MasterPrivKey := "xprv9s21ZrQH143K3QTDL4LXw2F7HEK3wJUD2nW2nRk4stbPy6cq3jPPqjiChkVvvNKmPGJxWUtg6LnF5kejMRNNU3TGtRBeJgk33yuGBxrMPHi"

	tests := []struct {
		name     string
		master   string
		coinType uint32
		acct     uint32
		private  bool
		wantAcct string
	}{
		// Test case
		{
			name:     "Test case 1",
			master:   testVec1MasterPrivKey,
			coinType: 0,
			acct:     0,
			private:  true,
			wantAcct: "xprv9yDtBMDXyMPDBEyJwf1yK8zxFEnDZ5xCJseGGwdAcie84qUbT5BwmWxt3uQMUgjRp7Qi2zoKiqLVsbLZFYzbboDPhnX8pRHCdkzeYQ8YtPn",
		},
		{
			name:     "Test case 2",
			master:   testVec1MasterPrivKey,
			coinType: 0,
			acct:     0,
			private:  false,
			wantAcct: "xpub6CDEarkRoiwWPj3n3gYygGwgoGchxYg3g6Zs5L2nB4B6wdojzcWCKKHMu9XuY1GyYygRfrVembjAko1T5xTsxj7ecKXxEPzDxx7nCK8Dxtx",
		},
		{
			name:     "Test case 3",
			master:   testVec1MasterPrivKey,
			coinType: 0,
			acct:     1,
			private:  true,
			wantAcct: "xprv9yDtBMDXyMPDE9ip6xBmK2SXn4D3oRqXxEhqE7pMJawe3MV6t7tK95WRT5sD7m3245ES1yeamCjobDoiqBALnVACfMFap5AX4EKPoHumASf",
		},
		{
			name:     "Test case 4",
			master:   testVec1MasterPrivKey,
			coinType: 0,
			acct:     1,
			private:  false,
			wantAcct: "xpub6CDEarkRoiwWSdoHCyimgAPGL63YCtZPKTdS2WDxrvUcv9pFRfCZgspuJLdc9Pma3mqsGMHYEzeLXBGhEKPU1tEyP9dwzWf5ErMVpZMnVEF",
		},
		{
			name:     "Test case 5",
			master:   testVec1MasterPrivKey,
			coinType: 1,
			acct:     0,
			private:  true,
			wantAcct: "xprv9z95ojsbDHs3odWg6Agnq1yX5NZTja3DFMN6NSYXJmDb5fZ9Y71UHLPLdDVFRheimvQdicAc7FC49FJVnSfX9iMDZF4fPFGkpKaQ6bBDJ1R",
		},
		{
			name:     "Test case 6",
			master:   testVec1MasterPrivKey,
			coinType: 1,
			acct:     0,
			private:  false,
			wantAcct: "xpub6D8SDFQV3fRM27b9CCDoC9vFdQPx92m4caHhApx8s6kZxTtJ5eKiq8hpUVoACxvvXSUAPAHGKXsutTQ6j948ZDqtJJWnTHJATE7cBiLWqPU",
		},
		{
			name:     "Test case 7",
			master:   testVec1MasterPrivKey,
			coinType: 1,
			acct:     1,
			private:  true,
			wantAcct: "xprv9z95ojsbDHs3rstcwrQb23zpHD3ggY4gqQ3viKiaSZhYUiwfNdvuon1vq8pKjwmFATaH33sbc7jyAyLxZE3WMwwWkVcWgDnPj7uZEtxH2y5",
		},
		{
			name:     "Test case 8",
			master:   testVec1MasterPrivKey,
			coinType: 1,
			acct:     1,
			private:  false,
			wantAcct: "xpub6D8SDFQV3fRM5My63swbPBwYqEtB5znYCcyXWi8BzuEXMXGovBFAMaLQgPLmBQerC7eU9vWFo2Lpf9uX5CMDY1wSDG46CjebrCDffQwpFhw",
		},
		{
			name:     "Test case 9",
			master:   testVec1MasterPrivKey,
			coinType: 60,
			acct:     0,
			private:  true,
			wantAcct: "xprv9yesRFVhFULSvcjW2xPLhy5mYaW53TkEZZtixvzNGG8H4jTyYufCZhaC6DePWkp5KaoedxJKUMD7GGiWX1LPPTZVJjufeoW66K2T929MBVk",
		},
		{
			name:     "Test case 10",
			master:   testVec1MasterPrivKey,
			coinType: 60,
			acct:     0,
			private:  false,
			wantAcct: "xpub6CeDpm2b5qtk96oy8yvM572W6cLZSvU5vnpKmKPypbfFwXo86SyT7VtfwWtMZAgZ5eKVMU9NnULt91HBFw9j62wJrcoc1ZRWiNvoorwBRXL",
		},
		{
			name:     "Test case 11",
			master:   testVec1MasterPrivKey,
			coinType: 60,
			acct:     1,
			private:  true,
			wantAcct: "xprv9yesRFVhFULSwnUxHwQiJ2EFto1kDue84LnZo1JPn6NdxYaE1VCvQ9AhCNkCswbLYpP9bRP2EaE5W32Y6p6Y7QxsoREqauexB4mLvsjC37w",
		},
		{
			name:     "Test case 12",
			master:   testVec1MasterPrivKey,
			coinType: 0,
			acct:     1,
			private:  false,
			wantAcct: "xpub6CDEarkRoiwWSdoHCyimgAPGL63YCtZPKTdS2WDxrvUcv9pFRfCZgspuJLdc9Pma3mqsGMHYEzeLXBGhEKPU1tEyP9dwzWf5ErMVpZMnVEF",
			//wantAcct:"",
		},
	}
	for i, test := range tests {
		extKey, err := hdkeychain.NewKeyFromString(test.master)
		if err != nil {
			t.Errorf("NewKeyFromString #%d (%s): unexpected error "+
				"creating extended key: %v", i, test.name, err)
			continue
		}

		acct, err := kc.ExportAccount(extKey, test.coinType, test.acct, test.private)
		if err != nil {
			t.Errorf("ExportAccount #%d (%s): unexpected error exporting account: %v", i, test.name, err)
			continue
		}

		//fmt.Printf("%s : %s\n", test.name, acct)
		if strings.Compare(test.wantAcct, acct) != 0 {
			t.Errorf("Accout export #%d (%s): the result is mismatched -- got: %s, want: %s", i, test.name,
				acct, test.wantAcct)
		}
	}
}

func TestKeyChain_NextAddress(t *testing.T) {
	// The private extended keys for test vectors in [BIP32].
	testVec1MasterPrivKey := "xprv9s21ZrQH143K33WYRm3XiBbxQMoucvL5bwa3RpUmzH2yzpfRTBokUYMeL4uv1DkN5wrgx8K29ZxEY36QajxXYSPnDwP7WfVTwANMAcvW71T"
	indexDefault := uint32(5);
	tests := []struct {
		name      string
		master    string
		coinType  uint32
		acct      uint32
		numberAdd uint32
		index     *uint32
		addresses []kc.AddressInfo
	}{
		// Test case
		{ // Test 2 addresses with coin type is BTC, index is default (0), acct is 0
			name: "Test case 1",
			master: testVec1MasterPrivKey,
			coinType: 0,
			acct: 0,
			numberAdd: uint32(2),
			addresses: []kc.AddressInfo{{0, "m/44'/0'/0'/0/0", "15gr1GJsYZvmjHe3p5bpkkHQMfqbjhNt1x"},
				{1, "m/44'/0'/0'/0/1", "1Akjmse8E1n1NsbJRTjc8XNkZ6pEV7YDeD"}},
		},
		{ // Test 2 addresses with coin type is BTC, index is default (0), acct is 1
			name: "Test case 2",
			master: testVec1MasterPrivKey,
			coinType: 0,
			acct: 1,
			numberAdd: uint32(2),
			addresses: []kc.AddressInfo{{0, "m/44'/0'/1'/0/0", "1HJbHWPUoL18ULqNnnr6Wg1HCLahVPiyiv"},
				{1, "m/44'/0'/1'/0/1", "1B8X7hDGsjca9CyGNbmFUzr8AWjU6W4gp9"}},
		},
		{ // Test 2 addresses with coin type is ETH, index is default (0), acct is 0
			name: "Test case 3",
			master: testVec1MasterPrivKey,
			coinType: 60,
			acct: 0,
			numberAdd: uint32(2),
			addresses: []kc.AddressInfo{{0, "m/44'/60'/0'/0/0", "0xA176f9e0BBF09c8132B031fe7c6C11DB52010EA3"},
				{1, "m/44'/60'/0'/0/1", "0xE47628629dbB118b21f2985dFef90140852A7343"}},
		},
		{ // Test generate 1 address with coin type is ETH, index is 5, acct is 0
			name: "Test case 4",
			master: testVec1MasterPrivKey,
			coinType: 60,
			acct: 0,
			numberAdd: uint32(1),
			index: &indexDefault,
			addresses: []kc.AddressInfo{{5, "m/44'/60'/0'/0/5", "0x0fB3034C8fB086b6fCAA709Cbfd48D66334a1e79"}},
		},
		{ // Test generate 2 addresses with coin type is ETH, index starts from 5, acct is 0
			name: "Test case 5",
			master: testVec1MasterPrivKey,
			coinType: 60,
			acct: 0,
			numberAdd: uint32(2),
			index: &indexDefault,
			addresses: []kc.AddressInfo{{5, "m/44'/60'/0'/0/5", "0x0fB3034C8fB086b6fCAA709Cbfd48D66334a1e79"},
				{6, "m/44'/60'/0'/0/6", "0x64750179F9ed8B2EE0068B15cA0c59F3a07cC9fd"}},
		},
	}

	for i, test := range tests {
		extKey, err := hdkeychain.NewKeyFromString(test.master)
		if err != nil {
			t.Errorf("NewKeyFromString #%d (%s): unexpected error "+
				"creating extended key: %v", i, test.name, err)
			continue
		}
		//var addresses []kc.AddressInfo
		addresses, err := kc.NewKeyChain(extKey, test.coinType).NextAddress(test.acct, test.numberAdd, test.index)
		if err != nil {
			t.Errorf("NextAddress #%d (%s): unexpected error exporting account: %v", i, test.name, err)
			continue
		}

		if !reflect.DeepEqual(test.addresses, addresses) {
			t.Errorf("NextAddress (%s): the result is mismatched -- got: %s, want: %s", test.name,
				addresses, test.addresses)
			continue
		}
	}
}