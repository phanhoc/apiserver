package main

import (
	"nextop/c-horde/offlinetool/rpc/rpcserver"
)

/**
* The main entry point
*/

func main() {

	rpcserver.StartRPCServers()

}
