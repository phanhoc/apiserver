package mnemonic

import (
	"github.com/tyler-smith/go-bip39"
	"errors"
	"nextop/c-horde/offlinetool/internal"
)

// Please refer the link: https://iancoleman.io/bip39/ for purpose double check result

type Mnemonic struct {
	EntropySize int
	Password    string
}

func NewMnemonicWithDefaultOption() *Mnemonic {
	return &Mnemonic{EntropySize: internal.DefaultEntropySize, Password: internal.DefaultSeedPass}
}

// New mnemonic follow the bip39
func (m *Mnemonic) GenerateMnemonic() (string, error) {
	entropy, err := bip39.NewEntropy(m.EntropySize)
	if err != nil {
		return "", err
	}

	return bip39.NewMnemonic(entropy)
}

// Generate seed from mnemonic and pass( optional )
func (m *Mnemonic) GenerateSeed(mnemonic string) ([]byte, error) {
	if !bip39.IsMnemonicValid(mnemonic) {
		return nil, errors.New("Invalid mnemonic: " + mnemonic)
	}
	return bip39.NewSeed(mnemonic, m.Password), nil
}
