package mnemonic_test

import (
	"nextop/c-horde/offlinetool/mnemonic"
	"log"
	"encoding/hex"
	"fmt"
	"testing"
)

func TestMnemonic_Create(t *testing.T) {
	mnemonic := mnemonic.NewMnemonicWithDefaultOption()

	m, err := mnemonic.GenerateMnemonic()
	if err != nil {
		t.Fatal(err)
	}

	t.Log("Create mnemonic: ", m)
}

func ExampleMnemonic_GenerateSeed() {
	mnemonic := mnemonic.NewMnemonicWithDefaultOption()
	seed, err := mnemonic.GenerateSeed("crawl resemble account note burger outer cake explain thrive lake element slide foil wine coffee cook planet crowd beach fuel chicken border club erode")

	if err != nil {
		log.Fatal(err)
	}

	fmt.Println("seed:", hex.EncodeToString(seed))

	// Output:
	// seed: d57bbd36db5606d5f4d9423c92c1542537beaa3e3c59664ef6dc6e8b040ff3328317920d0a233f7b95299e585c3a6a8dbcbed5d01b2a86d1445615ae0da780c2
}
