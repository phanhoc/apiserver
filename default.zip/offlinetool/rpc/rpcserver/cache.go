package rpcserver

import (
	"sync"
	"github.com/btcsuite/btcutil/hdkeychain"
	"github.com/btcsuite/btcd/chaincfg"
)

// WalletInfo contents details info of the new created wallet
// that will be used to serve gRPC requests
type WalletInfo struct {
	WalletId int32
	Mnemonic *string
	Seed     []byte
	Master   *hdkeychain.ExtendedKey
}

// Todo: Need to consider the usage sync.Map if possible
type ServerCache struct {
	wallets map[int32]*WalletInfo
	num     int32
	mu      sync.Mutex
}

// Init server cache
// Must call Init before call other function
func NewServerCache() *ServerCache {
	sc := &ServerCache{}
	sc.wallets = make(map[int32]*WalletInfo)
	sc.num = 0
	return sc
}

// Add sets a wallet information into cache that info will be used by wallet service
func (sc *ServerCache) Add(mnemonic *string, seed []byte) (int32, error) {
	sc.mu.Lock()
	defer sc.mu.Unlock()

	index := sc.num
	master, err := hdkeychain.NewMaster(seed, &chaincfg.MainNetParams) //TODO: chain config
	if err != nil {
		return -1, err
	}
	sc.wallets[index] = &WalletInfo{
							WalletId: index,
							Mnemonic: mnemonic,
							Seed: seed,
							Master: master}
	sc.num = sc.num + 1
	return index, nil
}

// Get gets a wallet information that correspond to walletId from cache
func (sc *ServerCache) Get(walletId int32) *WalletInfo {
	sc.mu.Lock()
	defer sc.mu.Unlock()

	info, ok := sc.wallets[walletId]
	if !ok {
		return nil
	}

	return info
}
