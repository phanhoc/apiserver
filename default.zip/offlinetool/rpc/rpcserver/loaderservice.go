package rpcserver

import (
	"log"
	"golang.org/x/net/context"
	pb "nextop/c-horde/offlinetool/rpc/toolrpc"
	"nextop/c-horde/offlinetool/mnemonic"
	"encoding/hex"
	"nextop/c-horde/offlinetool/crypto"
	"errors"
	"nextop/c-horde/offlinetool/internal"
	"google.golang.org/grpc"
)

var (
	ErrInvalidWalletSeedSize = errors.New("Invalid wallet seed size")
)

// loaderServer provides RPC clients with the ability to load and close wallets
type loaderServer struct {
	mnemonic    *mnemonic.Mnemonic
	serverCache *ServerCache
}

// StartWalletLoaderService creates an implementation of the WalletLoaderService
// and registers it with the gRPC server.
func StartWalletLoaderService(server *grpc.Server, cache *ServerCache) {
	m := mnemonic.NewMnemonicWithDefaultOption()
	service := &loaderServer{mnemonic: m, serverCache: cache}
	pb.RegisterWalletLoaderServiceServer(server, service)
}

func (ls *loaderServer) CreateWallet(ctx context.Context, req *pb.CreateWalletRequest) (*pb.CreateWalletResponse, error) {
	log.Println("Recevied CreateWallet request")

	m, err := ls.mnemonic.GenerateMnemonic()
	if err != nil {
		return nil, err   // TODO: need convert to grpc error
	}

	seed, err := ls.mnemonic.GenerateSeed(m)
	if err != nil {
		return nil, err
	}

	walletId, err := ls.serverCache.Add(&m, seed)
	if err != nil {
		return nil, err
	}

	res := pb.CreateWalletResponse{WalletId: walletId,
		Mnemonic: m,
		Seed: hex.EncodeToString(seed)}

	log.Printf("LoaderServer CreateWallet response: %#v \n", res)

	return &res, nil
}

func (ls *loaderServer) OpenWallet(ctx context.Context, req *pb.OpenWalletRequest) (*pb.OpenWalletResponse, error) {
	log.Println("Recevied CreateWallet request")

	passphrase := req.GetPassphrase()
	seedInfo := crypto.SeedInfo{}

	err := crypto.NewEncrypter(req.GetFilePath(), &passphrase).ReadEncrytedFile(&seedInfo)
	if err != nil {
		return nil, err
	}

	if len(seedInfo.Seed) != internal.WalletSeedSize {
		return nil, ErrInvalidWalletSeedSize
	}

	walletId, err := ls.serverCache.Add(nil, seedInfo.Seed)
	if err != nil {
		return nil, err
	}

	res := pb.OpenWalletResponse{WalletId: walletId,
		Seed: hex.EncodeToString(seedInfo.Seed)}

	log.Printf("LoaderServer OpenWallet response: %#v \n", res)

	return &res, nil
}


