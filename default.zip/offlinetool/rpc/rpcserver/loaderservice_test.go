package rpcserver

import (
	"testing"
	"google.golang.org/grpc"
	"time"
	pb "nextop/c-horde/offlinetool/rpc/toolrpc"
	"golang.org/x/net/context"
	"nextop/c-horde/offlinetool/internal"
	"path/filepath"
)

func Test_CreateWallet(t *testing.T) {

	conn, err := grpc.Dial("localhost"+internal.OfflineToolPort, grpc.WithInsecure())
	if err != nil {
		t.Fatalf("Could not connect: %v", err)
		return
	}
	defer conn.Close()
	c := pb.NewWalletLoaderServiceClient(conn)

	ctx, cancel := context.WithTimeout(context.Background(), time.Second*2)
	defer cancel()

	r, err := c.CreateWallet(ctx, &pb.CreateWalletRequest{})

	if err != nil {
		t.Fatalf("Could not generate mnemonic: %v", err)
		return
	}
	t.Logf("Response from rpc server: %s", r.String())

}

func Test_OpenWallet(t *testing.T) {

	conn, err := grpc.Dial("localhost"+internal.OfflineToolPort, grpc.WithInsecure())
	if err != nil {
		t.Fatalf("Could not connect: %v", err)
		return
	}
	defer conn.Close()
	c := pb.NewWalletLoaderServiceClient(conn)

	ctx, cancel := context.WithTimeout(context.Background(), time.Second*2)
	defer cancel()

	filename := filepath.Join("./crypto/", "keystoreSeed.json")
	passPhrase := "qwertyu@123"

	r, err := c.OpenWallet(ctx, &pb.OpenWalletRequest{FilePath: filename,
		Passphrase: passPhrase})

	if err != nil {
		t.Fatalf("Could not generate mnemonic: %v", err)
		return
	}
	t.Logf("Response from rpc server: %s", r.String())

}
