package rpcserver

import (
	"google.golang.org/grpc"
	"nextop/c-horde/offlinetool/internal"
	"log"
	"net"
)

func StartRPCServers() {

	lis, err := net.Listen("tcp", internal.OfflineToolPort)
	if err != nil {
		log.Fatalf("failed to listen: %v", err)
	}

	server := grpc.NewServer()
	cache := NewServerCache()

	StartWalletLoaderService(server, cache)
	StartWalletService(server, cache)

	if err := server.Serve(lis); err != nil {
		log.Fatalf("failed to serve: %v", err)
	}

}
