package rpcserver

import (
	"google.golang.org/grpc"
	pb "nextop/c-horde/offlinetool/rpc/toolrpc"
	"context"
	"nextop/c-horde/offlinetool/keychain"
	"google.golang.org/grpc/status"
	"google.golang.org/grpc/codes"
	"path/filepath"
	"strconv"
	"strings"
	"nextop/c-horde/offlinetool/crypto"
)

// walletServer provides wallet services for RPC clients.
type walletServer struct {
	cache *ServerCache
}

// StartWalletService creates an implementation of the WalletService and
// registers it with the gRPC server.
func StartWalletService(server *grpc.Server, cache *ServerCache) {
	service := &walletServer{cache}
	pb.RegisterWalletServiceServer(server, service)
}

func (s *walletServer) CreateAccount(ctx context.Context, req *pb.CreateAccountRequest) (*pb.CreateAccountResponse, error) {
	// Get master HD key from cache
	wallet := s.cache.Get(req.WalletId)
	if wallet == nil || wallet.Master == nil {
		return nil, status.Errorf(codes.NotFound,
			"grpc: walletId [%d] doesn't exist.", req.WalletId)
	}

	// Create single account from master key
	acct, err := keychain.NextAccount(wallet.Master, uint32(req.CoinType), 1, uint32(req.AccountIndex))
	if err != nil {
		return nil, status.Errorf(codes.Internal,
			"grpc: walletId [%d] generates account [%d] failed: %s", req.WalletId, req.AccountIndex, err.Error())
	}

	if len(acct) != 1 {
		return nil, status.Errorf(codes.Internal, "grpc: walletId [%d] generates more than one account", req.WalletId)
	}
	resp := &pb.CreateAccountResponse{
		AccountIndex: req.AccountIndex,
		Path:         acct[0],
	}
	return resp, nil
}

func (s *walletServer) CreateMultisigAccount(ctx context.Context, req *pb.CreateMultisigAccountRequest) (*pb.CreateMultisigAccountResponse, error) {
	return nil, nil
}

func (s *walletServer) ExportAccount(ctx context.Context, req *pb.ExportAccountRequest) (*pb.ExportAccountResponse, error) {
	// Get master HD key from cache
	wallet := s.cache.Get(req.WalletId)
	if wallet == nil || wallet.Master == nil {
		return nil, status.Errorf(codes.NotFound,
			"grpc: walletId [%d] doesn't exist.", req.WalletId)
	}

	acctPath, err := keychain.NextAccount(wallet.Master, uint32(req.CoinType), 1, uint32(req.AccountIndex))
	if err != nil {
		return nil, status.Errorf(codes.Internal,
			"grpc: walletId [%d] generates account [%d] failed: %s", req.WalletId, req.AccountIndex, err.Error())
	}

	acctKey, err := keychain.ExportAccount(wallet.Master, uint32(req.CoinType), uint32(req.AccountIndex), req.WatchOnly)
	if err != nil {
		return nil, status.Errorf(codes.Internal,
			"grpc: walletId [%d] exports account [%d] failed: %s", req.WalletId, req.AccountIndex, err.Error())
	}

	// format data encrypt: "acctKey;acctPath" -
	// "xprv9yDtBMDXyMPDBEyJwf1yK8zxFEnDZ5xCJseGGwdAcie84qUbT5BwmWxt3uQMUgjRp7Qi2zoKiqLVsbLZFYzbboDPhnX8pRHCdkzeYQ8YtPn;m/44'/0'/0'"
	var data []string
	data = append(data, acctKey)
	data = append(data, acctPath[0])
	rawData := strings.Join(data, ";")

	fileName := "keystoreAccount" + strconv.FormatInt(int64(req.AccountIndex), 10) + ".json"
	filePath := filepath.Join(req.FilePath, fileName)

	passPhrase := req.GetPassPhrase() //TODO: need add two part of passPhrase = severPass+customerPass
	encrypt := crypto.NewEncrypter(filePath, &passPhrase)
	err = encrypt.WriteEncryptedFile(rawData);
	if err != nil {
		return nil, status.Errorf(codes.Internal,
			"grpc: walletId [%d] encrypts account [%d] failed: %s", req.WalletId, req.AccountIndex, err.Error())
	}

	resp := &pb.ExportAccountResponse{
		AccountIndex: req.AccountIndex,
	}

	return resp, nil
}

func (s *walletServer) NextAddress(ctx context.Context, req *pb.NextAddressRequest) (*pb.NextAddressResponse, error) {
	// Get master HD key from cache
	wallet := s.cache.Get(req.WalletId)
	if wallet == nil || wallet.Master == nil {
		return nil, status.Errorf(codes.NotFound,
			"grpc: walletId [%d] doesn't exist.", req.WalletId)
	}
	addresIndex := uint32(req.AddressIndex);
	addressesInfo, err := keychain.NewKeyChain(wallet.Master, uint32(req.CoinType)).NextAddress(uint32(req.AccountIndex), uint32(req.AddressNumber), &addresIndex)
	if err != nil {
		return nil, status.Errorf(codes.Internal,
			"grpc: walletId [%d] generates address failed: %s", req.WalletId, err.Error())
	}
	if len(addressesInfo) != int(req.AddressNumber) {
		return nil, status.Errorf(codes.Internal, "grpc: walletId [%d] generates more than %d address", req.AddressNumber)
	}
	addressRes := make(*pb.AddressInfo, 0, len(addressesInfo))
	for _, addressInfo := range addressesInfo {
		var add pb.AddressInfo
		add.AddressIndex = int32(addressInfo.AddressIndex)
		add.AddressPath = addressInfo.AddressPath
		add.Address = addressInfo.Address
		addressRes = append(addressRes, add)
	}
	resp := &pb.NextAddressResponse{
		Addresses:&addressRes
	}
	return resp, nil
}
