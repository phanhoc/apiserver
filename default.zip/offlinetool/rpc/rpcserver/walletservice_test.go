package rpcserver_test

import (
	"testing"
	"google.golang.org/grpc"
	"nextop/c-horde/offlinetool/internal"
	pb "nextop/c-horde/offlinetool/rpc/toolrpc"
	"time"
	"golang.org/x/net/context"
)

func TestWalletServer_CreateAccount(t *testing.T) {
	conn, err := grpc.Dial("localhost"+internal.OfflineToolPort, grpc.WithInsecure())
	if err != nil {
		t.Fatalf("Could not connect: %v", err)
		return
	}
	defer conn.Close()
	c := pb.NewWalletLoaderServiceClient(conn)

	ctx, cancel := context.WithTimeout(context.Background(), time.Second*2)
	defer cancel()

	r, err := c.CreateWallet(ctx, &pb.CreateWalletRequest{})

	if err != nil {
		t.Fatalf("Could not generate mnemonic: %v", err)
		return
	}

	walletCli := pb.NewWalletServiceClient(conn)
	resp, err := walletCli.CreateAccount(ctx, &pb.CreateAccountRequest{
		WalletId: r.WalletId,
		CoinType: 0,
		AccountIndex: 0,
	})

	if err != nil {
		t.Fatalf("Could not create account: %v", err)
		return
	}
	t.Logf("AccountPath: %s", resp.String())
}

func TestWalletServer_ExportAccount(t *testing.T) {
	conn, err := grpc.Dial("localhost"+internal.OfflineToolPort, grpc.WithInsecure())
	if err != nil {
		t.Fatalf("Could not connect: %v", err)
		return
	}
	defer conn.Close()
	c := pb.NewWalletLoaderServiceClient(conn)

	ctx, cancel := context.WithTimeout(context.Background(), time.Second*2)
	defer cancel()

	r, err := c.CreateWallet(ctx, &pb.CreateWalletRequest{})

	if err != nil {
		t.Fatalf("Could not generate mnemonic: %v", err)
		return
	}

	walletCli := pb.NewWalletServiceClient(conn)
	resp, err := walletCli.ExportAccount(ctx, &pb.ExportAccountRequest{
		WalletId: r.WalletId,
		CoinType: 0,
		AccountIndex: 1,
		WatchOnly: false,
		PassPhrase: "passWord",
		FilePath: "C:\\Users\\PSPC141\\Desktop\\Test",
	})

	if err != nil {
		t.Fatalf("Could not export account: %v", err)
		return
	}
	t.Logf("Response: %s", resp.String())
}

func TestWalletServer_NextAddress(t *testing.T) {
	conn, err := grpc.Dial("localhost"+internal.OfflineToolPort, grpc.WithInsecure())
	if err != nil {
		t.Fatalf("Could not connect: %v", err)
		return
	}
	defer conn.Close()
	c := pb.NewWalletLoaderServiceClient(conn)

	ctx, cancel := context.WithTimeout(context.Background(), time.Second*2)
	defer cancel()

	r, err := c.CreateWallet(ctx, &pb.CreateWalletRequest{})

	if err != nil {
		t.Fatalf("Could not generate mnemonic: %v", err)
		return
	}

	walletCli := pb.NewWalletServiceClient(conn)
	resp, err := walletCli.NextAddress(ctx, &pb.NextAddressRequest{
		WalletId:r.WalletId,
		CoinType:0,
		AccountIndex:0,
		AddressNumber:2,
		AddressIndex:0,
	})

	if err != nil {
		t.Fatalf("Could not generate address: %v", err)
		return
	}
	t.Logf("Response: %s", resp.String())
}